package net.oldmanyounger.shroud.item;

import net.minecraft.world.item.Item;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.neoforge.common.DeferredSpawnEggItem;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredRegister;
import net.oldmanyounger.shroud.Shroud;
import net.oldmanyounger.shroud.entity.ModEntities;

public class ModItems {

    // Central deferred register used to register all item instances for the Shroud mod
    // This includes standalone items and BlockItems created from registered blocks
    public static final DeferredRegister.Items ITEMS =
            DeferredRegister.createItems(Shroud.MOD_ID);


    // Entry point called from the main mod class to attach this item registry to the mod event bus
    // Once registered, any items added to ITEMS will be created and available at runtime
    public static void register(IEventBus eventBus) {
        ITEMS.register(eventBus);
    }

    public static final DeferredItem<Item> GECKO_SPAWN_EGG = ITEMS.register("gecko_spawn_egg",
            () -> new DeferredSpawnEggItem(ModEntities.GECKO, 0x31afaf, 0xffac00,
                    new Item.Properties()));
}
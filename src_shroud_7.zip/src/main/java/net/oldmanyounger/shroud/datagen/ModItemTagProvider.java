package net.oldmanyounger.shroud.datagen;


import net.oldmanyounger.shroud.Shroud;
import net.oldmanyounger.shroud.block.ModBlocks;
import net.minecraft.core.HolderLookup;
import net.minecraft.data.PackOutput;
import net.minecraft.data.tags.ItemTagsProvider;
import net.minecraft.tags.ItemTags;
import net.minecraft.world.level.block.Block;
import net.neoforged.neoforge.common.data.ExistingFileHelper;
import org.jetbrains.annotations.Nullable;

import java.util.concurrent.CompletableFuture;

public class ModItemTagProvider extends ItemTagsProvider {
    public ModItemTagProvider(PackOutput output, CompletableFuture<HolderLookup.Provider> lookupProvider,
                              CompletableFuture<TagLookup<Block>> blockTags, @Nullable ExistingFileHelper existingFileHelper) {
        super(output, lookupProvider, blockTags, Shroud.MOD_ID, existingFileHelper);
    }

    @Override
    protected void addTags(HolderLookup.Provider provider) {
        // Sculk wood item tags
        this.tag(ItemTags.LOGS_THAT_BURN)
                .add(ModBlocks.SCULK_LOG.get().asItem())
                .add(ModBlocks.SCULK_WOOD.get().asItem())
                .add(ModBlocks.STRIPPED_SCULK_LOG.get().asItem())
                .add(ModBlocks.STRIPPED_SCULK_WOOD.get().asItem());

        this.tag(ItemTags.PLANKS)
                .add(ModBlocks.SCULK_PLANKS.asItem());
    }
}
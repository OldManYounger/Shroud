package net.oldmanyounger.shroud;

import com.mojang.logging.LogUtils;
import net.minecraft.client.renderer.entity.EntityRenderers;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.fml.common.Mod;
import net.neoforged.fml.event.lifecycle.FMLClientSetupEvent;
import net.neoforged.fml.event.lifecycle.FMLCommonSetupEvent;
import net.oldmanyounger.shroud.block.ModBlocks;
import net.oldmanyounger.shroud.entity.ModEntities;
import net.oldmanyounger.shroud.entity.client.GeckoRenderer;
import net.oldmanyounger.shroud.item.ModCreativeModeTabs;
import net.oldmanyounger.shroud.item.ModItems;
import org.slf4j.Logger;

@Mod(Shroud.MOD_ID)
public class Shroud {

    // The unique mod identifier used as the namespace for all registered content
    public static final String MOD_ID = "shroud";

    // Logger instance for this mod, useful for debugging and status messages
    public static final Logger LOGGER = LogUtils.getLogger();


    // The constructor is called by NeoForge when the mod is loaded and receives the mod event bus
    // Here we hook into lifecycle events and register our blocks, items, and creative tabs
    public Shroud(IEventBus modEventBus) {

        // Register the common setup method to run during the FMLCommonSetupEvent phase
        modEventBus.addListener(this::commonSetup);

        // Register this mod's custom creative mode tabs so they are created before items are added
        ModCreativeModeTabs.register(modEventBus);

        // Register all block definitions (including the custom log) to the game registry
        ModBlocks.register(modEventBus);

        // Register all item definitions, including BlockItems for registered blocks
        ModItems.register(modEventBus);

        // Register all entities
        ModEntities.register(modEventBus);
    }

    // Common setup runs on both client and server after registries are ready
    // Use this for cross-side initialization that does not depend on a specific physical side
    private void commonSetup(FMLCommonSetupEvent event) {
        // Intentionally left empty for now; can be used later for network handlers or other setup
    }

    // You can use EventBusSubscriber to automatically register all static methods in the class annotated with @SubscribeEvent
    @EventBusSubscriber(modid = MOD_ID, value = Dist.CLIENT)
    public static class ClientModEvents {
        @SubscribeEvent
        public static void onClientSetup(FMLClientSetupEvent event) {

            EntityRenderers.register(ModEntities.GECKO.get(), GeckoRenderer::new);
        }
    }
}

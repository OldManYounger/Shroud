package net.oldmanyounger.shroud.datagen;

import net.minecraft.core.Holder;
import net.minecraft.core.HolderLookup;
import net.minecraft.data.loot.BlockLootSubProvider;
import net.minecraft.world.flag.FeatureFlags;
import net.minecraft.world.level.block.Block;
import net.oldmanyounger.shroud.block.ModBlocks;

import java.util.Set;

public class ModBlockLootTableProvider extends BlockLootSubProvider {
    protected ModBlockLootTableProvider(HolderLookup.Provider registries) {
        super(Set.of(), FeatureFlags.REGISTRY.allFlags(), registries);
    }

    @Override
    protected void generate() {
        // Sculk wood drop-selves
        this.dropSelf(ModBlocks.SCULK_LOG.get());
        this.dropSelf(ModBlocks.SCULK_WOOD.get());
        this.dropSelf(ModBlocks.STRIPPED_SCULK_LOG.get());
        this.dropSelf(ModBlocks.STRIPPED_SCULK_WOOD.get());
        this.dropSelf(ModBlocks.SCULK_PLANKS.get());
        this.dropSelf(ModBlocks.SCULK_SAPLING.get());

        // Sculk leaves drop-saplings (and sticks)
        this.add(ModBlocks.SCULK_LEAVES.get(), block ->
                createLeavesDrops(block, ModBlocks.SCULK_SAPLING.get(), NORMAL_LEAVES_SAPLING_CHANCES));

        // Sculk wood other drop-selves
        dropSelf(ModBlocks.SCULK_STAIRS.get());
        add(ModBlocks.SCULK_SLAB.get(),
                block -> createSlabItemTable(ModBlocks.SCULK_SLAB.get()));

        dropSelf(ModBlocks.SCULK_BUTTON.get());
        dropSelf(ModBlocks.SCULK_PRESSURE_PLATE.get());

        dropSelf(ModBlocks.SCULK_FENCE.get());
        dropSelf(ModBlocks.SCULK_FENCE_GATE.get());
        dropSelf(ModBlocks.SCULK_WALL.get());

        dropSelf(ModBlocks.SCULK_TRAPDOOR.get());
        add(ModBlocks.SCULK_DOOR.get(),
                block -> createDoorTable(ModBlocks.SCULK_DOOR.get()));

    }

    @Override
    protected Iterable<Block> getKnownBlocks() {
        return ModBlocks.BLOCKS.getEntries().stream().map(Holder::value)::iterator;
    }
}

package net.oldmanyounger.shroud.item;

import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.ItemStack;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.neoforge.registries.DeferredRegister;
import net.oldmanyounger.shroud.Shroud;
import net.oldmanyounger.shroud.block.ModBlocks;

import java.util.function.Supplier;

public class ModCreativeModeTabs {

    // Deferred register for creative mode tabs assigned to the Shroud mod's namespace
    // This manages all custom tabs added by the mod
    public static final DeferredRegister<CreativeModeTab> CREATIVE_MODE_TABS =
            DeferredRegister.create(Registries.CREATIVE_MODE_TAB, Shroud.MOD_ID);


    // Primary creative tab for the Shroud mod, displaying all blocks and items the mod adds
    // The icon, title, and displayed contents can be expanded as more content is introduced
    public static final Supplier<CreativeModeTab> SHROUD_BLOCK_TAB = CREATIVE_MODE_TABS.register("shroud_blocks",
            () -> CreativeModeTab.builder().icon(() -> new ItemStack(ModBlocks.SCULK_LOG.get()))
                    .title(Component.translatable("creativetab.shroud.shroud_blocks"))
                    .displayItems((params, output) -> {
                        // Sculk wood entries
                        output.accept(ModBlocks.SCULK_LOG.get());
                        output.accept(ModBlocks.SCULK_WOOD.get());
                        output.accept(ModBlocks.STRIPPED_SCULK_LOG.get());
                        output.accept(ModBlocks.STRIPPED_SCULK_WOOD.get());
                        output.accept(ModBlocks.SCULK_PLANKS.get());
                        output.accept(ModBlocks.SCULK_LEAVES.get());
                        output.accept(ModBlocks.SCULK_SAPLING.get());

                        output.accept(ModBlocks.SCULK_PLANKS.get());
                        output.accept(ModBlocks.SCULK_STAIRS.get());
                        output.accept(ModBlocks.SCULK_SLAB.get());

                        output.accept(ModBlocks.SCULK_FENCE.get());
                        output.accept(ModBlocks.SCULK_FENCE_GATE.get());

                        output.accept(ModBlocks.SCULK_DOOR.get());
                        output.accept(ModBlocks.SCULK_TRAPDOOR.get());

                        output.accept(ModBlocks.SCULK_PRESSURE_PLATE.get());
                        output.accept(ModBlocks.SCULK_BUTTON.get());
                    }).build());

    public static final Supplier<CreativeModeTab> SHROUD_ITEM_TAB = CREATIVE_MODE_TABS.register("shroud_items",
            () -> CreativeModeTab.builder().icon(() -> new ItemStack(ModItems.GECKO_SPAWN_EGG.get()))
                    .withTabsBefore(ResourceLocation.fromNamespaceAndPath(Shroud.MOD_ID, "shroud_blocks"))
                    .title(Component.translatable("creativetab.shroud.shroud_items"))
                    .displayItems((itemDisplayParameters, output) -> {
                        output.accept(ModItems.GECKO_SPAWN_EGG.get());
                    }).build());

    // Registers this tab registry to the mod event bus
    // After registration, the tab appears in the Creative Mode UI in-game
    public static void register(IEventBus eventBus) {
        CREATIVE_MODE_TABS.register(eventBus);
    }
}
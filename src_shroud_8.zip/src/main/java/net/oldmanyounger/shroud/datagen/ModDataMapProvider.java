package net.oldmanyounger.shroud.datagen;

public class ModDataMapProvider {
}

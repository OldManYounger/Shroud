package net.oldmanyounger.shroud.datagen;

import net.minecraft.core.HolderLookup;
import net.minecraft.data.DataGenerator;
import net.minecraft.data.PackOutput;
import net.minecraft.data.loot.LootTableProvider;
import net.minecraft.world.level.storage.loot.parameters.LootContextParamSets;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.common.data.BlockTagsProvider;
import net.neoforged.neoforge.common.data.ExistingFileHelper;
import net.neoforged.neoforge.data.event.GatherDataEvent;
import net.oldmanyounger.shroud.Shroud;

import java.util.Collections;
import java.util.List;
import java.util.concurrent.CompletableFuture;

@EventBusSubscriber(modid = Shroud.MOD_ID)
public class DataGenerators {

    // Entry point for NeoForge's data-generation pipeline, invoked by the datagen run configuration
    @SubscribeEvent
    public static void gatherData(GatherDataEvent event) {

        // Main generator instance used to register all datagen providers
        DataGenerator generator = event.getGenerator();

        // Output location for generated assets and data files
        PackOutput packOutput = generator.getPackOutput();

        // File helper used to validate references to existing textures/models
        ExistingFileHelper existingFileHelper = event.getExistingFileHelper();

        // Registry lookup provider used by many datagen providers
        CompletableFuture<HolderLookup.Provider> lookupProvider = event.getLookupProvider();


        // Loot table generation
        generator.addProvider(event.includeServer(), new LootTableProvider(packOutput, Collections.emptySet(),
                        List.of(new LootTableProvider.SubProviderEntry(ModBlockLootTableProvider::new, LootContextParamSets.BLOCK)), lookupProvider));


        // Recipe generation
        generator.addProvider(event.includeServer(),
                new ModRecipeProvider(packOutput, lookupProvider));


        // Block tags generation
        BlockTagsProvider blockTagsProvider =
                new ModBlockTagProvider(packOutput, lookupProvider, existingFileHelper);
        generator.addProvider(event.includeServer(), blockTagsProvider);


        // Item tags generation
//        generator.addProvider(event.includeServer(),
//                new ModItemTagProvider(packOutput, lookupProvider, blockTagsProvider.contentsGetter(), existingFileHelper));


        // Item model generation
        generator.addProvider(event.includeClient(),
                new ModItemModelProvider(packOutput, existingFileHelper));


        // Blockstate + block model generation
        generator.addProvider(event.includeClient(),
                new ModBlockStateProvider(packOutput, existingFileHelper));


        // Optional datamap provider
//        generator.addProvider(event.includeServer(),
//                new ModDataMapProvider(packOutput, lookupProvider));


        // Optional datapack provider (dimensions, biomes, worldgen JSON)
        generator.addProvider(event.includeServer(),
                new ModDatapackProvider(packOutput, lookupProvider));
    }
}
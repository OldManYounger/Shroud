package net.oldmanyounger.shroud.client;

import net.oldmanyounger.shroud.block.ModBlocks;
import net.minecraft.client.renderer.BiomeColors;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.neoforge.client.event.RegisterColorHandlersEvent;
import net.neoforged.fml.loading.FMLEnvironment;
import net.neoforged.bus.api.IEventBus;

public final class ModColorHandlers {

    public static void register(IEventBus modBus) {
        if (FMLEnvironment.dist != Dist.CLIENT) {
            return;
        }

        modBus.addListener(ModColorHandlers::registerBlockColors);
        modBus.addListener(ModColorHandlers::registerItemColors);
    }

    private static void registerBlockColors(RegisterColorHandlersEvent.Block event) {
        event.register(
                (state, level, pos, tintIndex) -> {
                    if (tintIndex != 0) return -1;
                    if (level == null || pos == null) return -1;
                    return BiomeColors.getAverageGrassColor(level, pos);
                },
                ModBlocks.SCULK_GRASS.get()
        );
    }

    private static void registerItemColors(RegisterColorHandlersEvent.Item event) {
        event.register(
                (stack, tintIndex) -> tintIndex == 0 ? 0xFFFFFFFF : -1,
                ModBlocks.SCULK_GRASS.asItem()
        );
    }

    private ModColorHandlers() {}
}

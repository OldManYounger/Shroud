package net.oldmanyounger.shroud.worldgen.tree;

import net.minecraft.world.level.block.grower.TreeGrower;
import net.oldmanyounger.shroud.Shroud;
import net.oldmanyounger.shroud.worldgen.ModConfiguredFeatures;

import java.util.Optional;

public class ModTreeGrowers {
    public static final TreeGrower SCULK = new TreeGrower(Shroud.MOD_ID + ":purp",
            Optional.empty(), Optional.of(ModConfiguredFeatures.SCULK_KEY), Optional.empty());
}

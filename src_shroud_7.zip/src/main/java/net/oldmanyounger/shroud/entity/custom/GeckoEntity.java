package net.oldmanyounger.shroud.entity.custom;

import net.minecraft.world.item.Items;
import net.oldmanyounger.shroud.entity.ModEntities;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.AgeableMob;
import net.minecraft.world.entity.AnimationState;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.*;
import net.minecraft.world.entity.animal.Animal;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import org.jetbrains.annotations.Nullable;

public class GeckoEntity extends Animal {
    public final AnimationState idleAnimationState = new AnimationState();
    private int idleAnimationTimeout = 0;

    public GeckoEntity(EntityType<? extends Animal> entityType, Level level) {
        super(entityType, level);
    }

    @Override
    protected void registerGoals() {
        // Priority begins at 0, floating a mob should be the highest priority
        this.goalSelector.addGoal(0, new FloatGoal(this));

        // Panic goal is triggered when an entity is hit; some other goals
        this.goalSelector.addGoal(1, new PanicGoal(this, 2.0));

        // Breed goal is for when a mob gets a relevant breeding item
        this.goalSelector.addGoal(2, new BreedGoal(this, 1.0));

        // Tempt goal means entity will follow player when holding the relevant item
        this.goalSelector.addGoal(3, new TemptGoal(this, 1.25, stack -> stack.is(Items.SWEET_BERRIES), false));

        // Follow parent goal is for when none of the above goals are relevant
        this.goalSelector.addGoal(4, new FollowParentGoal(this, 1.25));

        // Water avoiding random stroll goal is somewhat of a default behavior when no parent is present
        this.goalSelector.addGoal(5, new WaterAvoidingRandomStrollGoal(this, 1.0));

        // Look at player goal will cause entity to sometimes look at the player if nearby
        this.goalSelector.addGoal(6, new LookAtPlayerGoal(this, Player.class, 6.0F));

        // Random look around goal will cause the entity to occasionally look around
        this.goalSelector.addGoal(7, new RandomLookAroundGoal(this));
    }

    // Necessary for all mob entities, to define basic attributes
    public static AttributeSupplier.Builder createAttributes() {
        return Animal.createLivingAttributes()
                .add(Attributes.MAX_HEALTH, 10d)
                .add(Attributes.MOVEMENT_SPEED, 0.25D)
                .add(Attributes.FOLLOW_RANGE, 24D);
    }

    // Food required to breed specified entity
    @Override
    public boolean isFood(ItemStack stack) {
        return stack.is(Items.SWEET_BERRIES);
    }

    // Allows baby entities
    @Nullable
    @Override
    public AgeableMob getBreedOffspring(ServerLevel level, AgeableMob otherParent) {
        return ModEntities.GECKO.get().create(level);
    }

    // Idle animation definer; idle animation timeout should be dependent on timing of animations in Blockbench
    private void setupAnimationStates() {
        if(this.idleAnimationTimeout <= 0) {
            this.idleAnimationTimeout = 80;
            this.idleAnimationState.start(this.tickCount);
        } else {
            --this.idleAnimationTimeout;
        }
    }

    @Override
    public void tick() {
        super.tick();

        // Certain animations only happen on client; bounding box and walking anims may be server-side
        if(this.level().isClientSide()) {
            this.setupAnimationStates();
        }
    }
}
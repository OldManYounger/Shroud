package net.oldmanyounger.shroud.datagen;

import net.minecraft.core.HolderLookup;
import net.minecraft.data.PackOutput;
import net.minecraft.tags.BlockTags;
import net.minecraft.world.level.block.Block;
import net.neoforged.neoforge.common.data.BlockTagsProvider;
import net.neoforged.neoforge.common.data.ExistingFileHelper;
import net.oldmanyounger.shroud.Shroud;
import net.oldmanyounger.shroud.block.ModBlocks;
import org.jetbrains.annotations.Nullable;

import java.util.concurrent.CompletableFuture;

public class ModBlockTagProvider extends BlockTagsProvider {

    // Constructor linking this provider to the Shroud namespace and registry lookup
    public ModBlockTagProvider(PackOutput output,
                               CompletableFuture<HolderLookup.Provider> lookupProvider,
                               @Nullable ExistingFileHelper existingFileHelper) {
        super(output, lookupProvider, Shroud.MOD_ID, existingFileHelper);
    }

    // Main method for defining block tag membership
    @Override
    protected void addTags(HolderLookup.Provider provider) {

        // All sculk wood-set blocks: axe-mineable wood-like blocks
        wooden(
                ModBlocks.SCULK_LOG.get(),
                ModBlocks.SCULK_WOOD.get(),
                ModBlocks.STRIPPED_SCULK_LOG.get(),
                ModBlocks.STRIPPED_SCULK_WOOD.get(),
                ModBlocks.SCULK_PLANKS.get(),
                ModBlocks.SCULK_STAIRS.get(),
                ModBlocks.SCULK_SLAB.get(),
                ModBlocks.SCULK_FENCE.get(),
                ModBlocks.SCULK_FENCE_GATE.get(),
                ModBlocks.SCULK_WALL.get(),
                ModBlocks.SCULK_DOOR.get(),
                ModBlocks.SCULK_TRAPDOOR.get(),
                ModBlocks.SCULK_BUTTON.get(),
                ModBlocks.SCULK_PRESSURE_PLATE.get()
        );

        // Logs / wood family
        tag(BlockTags.LOGS)
                .add(ModBlocks.SCULK_LOG.get())
                .add(ModBlocks.SCULK_WOOD.get())
                .add(ModBlocks.STRIPPED_SCULK_LOG.get())
                .add(ModBlocks.STRIPPED_SCULK_WOOD.get());

        tag(BlockTags.LOGS_THAT_BURN)
                .add(ModBlocks.SCULK_LOG.get())
                .add(ModBlocks.SCULK_WOOD.get())
                .add(ModBlocks.STRIPPED_SCULK_LOG.get())
                .add(ModBlocks.STRIPPED_SCULK_WOOD.get());

        // Planks
        tag(BlockTags.PLANKS)
                .add(ModBlocks.SCULK_PLANKS.get());

        // Leaves + sapling
        tag(BlockTags.LEAVES)
                .add(ModBlocks.SCULK_LEAVES.get());

        tag(BlockTags.SAPLINGS)
                .add(ModBlocks.SCULK_SAPLING.get());

        // Shape / role-specific tags for wood set
        stairs(ModBlocks.SCULK_STAIRS.get());
        slab(ModBlocks.SCULK_SLAB.get());

        fence(ModBlocks.SCULK_FENCE.get());
        fenceGate(ModBlocks.SCULK_FENCE_GATE.get());
        wall(ModBlocks.SCULK_WALL.get());

        door(ModBlocks.SCULK_DOOR.get());
        trapdoor(ModBlocks.SCULK_TRAPDOOR.get());

        button(ModBlocks.SCULK_BUTTON.get());
        pressurePlate(ModBlocks.SCULK_PRESSURE_PLATE.get());
    }

    // ---------- Helpers ----------

    // All blocks that should behave like wood (axe is the correct tool)
    private void wooden(Block... blocks) {
        tag(BlockTags.MINEABLE_WITH_AXE).add(blocks);
    }

    private void stairs(Block block) {
        tag(BlockTags.STAIRS).add(block);
        tag(BlockTags.WOODEN_STAIRS).add(block);
    }

    private void slab(Block block) {
        tag(BlockTags.SLABS).add(block);
        tag(BlockTags.WOODEN_SLABS).add(block);
    }

    private void fence(Block block) {
        tag(BlockTags.FENCES).add(block);
        tag(BlockTags.WOODEN_FENCES).add(block);
    }

    private void fenceGate(Block block) {
        tag(BlockTags.FENCE_GATES).add(block);
    }

    private void wall(Block block) {
        tag(BlockTags.WALLS).add(block);
    }

    private void door(Block block) {
        tag(BlockTags.DOORS).add(block);
        tag(BlockTags.WOODEN_DOORS).add(block);
    }

    private void trapdoor(Block block) {
        tag(BlockTags.TRAPDOORS).add(block);
        tag(BlockTags.WOODEN_TRAPDOORS).add(block);
    }

    private void button(Block block) {
        tag(BlockTags.BUTTONS).add(block);
        tag(BlockTags.WOODEN_BUTTONS).add(block);
    }

    private void pressurePlate(Block block) {
        tag(BlockTags.PRESSURE_PLATES).add(block);
        tag(BlockTags.WOODEN_PRESSURE_PLATES).add(block);
    }
}
